class Price {
    public var price = 2.0

    fun Calc_price(numb_tr : Int, numb_st : Double){
        price =  100.0 * numb_tr.toDouble() * numb_st.toDouble()
    }
}