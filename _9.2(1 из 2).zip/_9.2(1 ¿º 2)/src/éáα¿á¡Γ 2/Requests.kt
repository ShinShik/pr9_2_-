public class Requests(public val Station : String, val Time : String, val Date : String, )
{
    fun print_info(){
        println("Заявка на поездку до станции $Station\n$Date в $Time создана")
    }
}