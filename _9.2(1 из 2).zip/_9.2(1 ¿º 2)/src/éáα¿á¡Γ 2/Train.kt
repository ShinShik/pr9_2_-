class Train(public val numb : Int, public val stations : List<String>)
{
}