fun main() {
    val st_tr1 = listOf("Москва","Пермь","Екатеринбург")
    val st_tr2 = listOf("Челябинск","Екатеринбург","Санкт-Питербург")
    val st_tr3 = listOf("Орлов","Ленинград","Мосвка")
    var tr1 = Train(1,st_tr1)
    var tr2 = Train(2,st_tr2)
    var tr3 = Train(3,st_tr3)

    println("Введите станцию, дату и время")
    var req = Requests(readln(), readln(), readln())

    println("Введите своё имя")
    val pas = Passanger(readln(),req.Station)
    pas.choice(tr1.stations, tr2.stations, tr3.stations)

    val pr = Price()
    pr.Calc_price(pas.Train, pas.numb)

    val sel = Seller(req.Station, pas.Train, pr.price)
    sel.print_info()
}