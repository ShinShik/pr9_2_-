package `Вариант 4`

import jdk.jshell.Diag

class BankAccount(val accountNumber: String) {

    var Money = 0.0

    fun Inp_Money(money : Double){
        Money = money
    }

}