package `Вариант 4`

class Client(val name: String, val bankAccount: BankAccount, val creditCard: CreditCard) {

    fun makePayment(order: Order, amount: Double) {
        order.totalAmount+=amount
    }

    fun makeTransfer(account: BankAccount, amount: Double) {

    }

    fun Buy(order: Order){
        if (order.totalAmount <= bankAccount.Money){
            bankAccount.Money-=order.totalAmount
            println("Покупка успешно совершнена")
            var x = bankAccount.Money
            println("Осталось $x денег ")
        }
        else{
            println("Не хватает денег")
            blockCreditCard()
        }
    }

    fun blockCreditCard() {
        creditCard.block()
    }
}