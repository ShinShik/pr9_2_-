package `Вариант 4`

class Admin {

    fun blockCreditCard(client: Client, amount: Double, limit: Double) {
        if (amount > limit) {
            client.blockCreditCard()
        }
    }
}