package `Вариант 4`

class CreditCard(val cardNumber: String) {

    var isBlocked: Boolean = false

    fun block() {
        isBlocked = true
    }
}