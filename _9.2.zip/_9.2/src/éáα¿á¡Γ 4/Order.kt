package `Вариант 4`

class Order(val orderId: String, var totalAmount: Double)