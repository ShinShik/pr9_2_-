package `Вариант 4`

fun main() {

        val bankAccount = BankAccount("1234567890")
        val creditCard = CreditCard("9876543210")
        val client = Client("John Doe", bankAccount, creditCard)
        val order = Order("001", 0.0)
        val administrator = Admin()

        println("Введите кол-во денег на счету")
        println("Введите стоимость покупки")
        var q = readln()
        while (q != "стоп"){
            client.makePayment(order, 100.0)
            println("Желаете ещё что то купить?")
            q = readln()
        }
        client.makeTransfer(bankAccount, 50.0)
        administrator.blockCreditCard(client, 200.0, 150.0)
        client.Buy(order)

}