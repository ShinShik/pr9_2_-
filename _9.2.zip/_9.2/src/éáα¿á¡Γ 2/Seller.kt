public class Seller( val Station : String, val train : Int, val price : Double) {
    public fun print_info(){
        println("Вы можете поехать до $Station в поезде $train\nОбщая стоимость поездки = $price")
    }
}