public class Passanger (public val name : String, val station : String)
{
    public var Train = 0
    public var numb = 0.0

    fun Create_request(){
        println("Введите название станции, время и дату")
        val req = Requests(readln(), readln(), readln())
        req.print_info()
    }
    fun choice(tr1 : List<String>,tr2 : List<String>,tr3 : List<String>){
        when(station){
            in tr1 ->{ numb = tr1.indexOf(station)+1.toDouble(); Train=1}
            in tr2 ->{ numb = tr2.indexOf(station)+1.toDouble(); Train=2}
            in tr3 ->{ numb = tr3.indexOf(station)+1.toDouble(); Train=3}
            else -> println("Нет поезда отправляющегося в $station")
        }
    }
}